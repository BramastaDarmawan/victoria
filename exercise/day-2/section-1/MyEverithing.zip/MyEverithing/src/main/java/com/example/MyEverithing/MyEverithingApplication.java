package com.example.MyEverithing;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MyEverithingApplication {

	public static void main(String[] args) {
		SpringApplication.run(MyEverithingApplication.class, args);
	}

}
