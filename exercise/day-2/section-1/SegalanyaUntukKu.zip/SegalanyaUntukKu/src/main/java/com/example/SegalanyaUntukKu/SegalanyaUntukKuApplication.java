package com.example.SegalanyaUntukKu;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SegalanyaUntukKuApplication {

	public static void main(String[] args) {
		SpringApplication.run(SegalanyaUntukKuApplication.class, args);
	}

}
