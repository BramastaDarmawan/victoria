package com.example.My_Everything;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MyEverythingApplication {

	public static void main(String[] args) {
		SpringApplication.run(MyEverythingApplication.class, args);
	}

}
